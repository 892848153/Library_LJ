package com.lj.library.fragment.dagger;

/**
 * Created by liujie_gyh on 16/6/26.
 */
public class FieldInjection {

    private String mName;

    public FieldInjection(String name) {
        mName = name;
    }
}
