package com.lj.library.fragment;

/**
 * Created by liujie_gyh on 15/9/4.
 */
public interface BackHandlerInterface {

     void setSelectedFragment(FragmentBackManager selectedFragment);
}
