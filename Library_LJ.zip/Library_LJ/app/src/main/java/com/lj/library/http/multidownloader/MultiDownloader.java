package com.lj.library.http.multidownloader;

/**
 * 
 * 多线程断点续传下载器.
 * 
 * @time 2014年10月30日 下午6:32:15
 * @author jie.liu
 */
public class MultiDownloader {

}
