package com.lj.library.http.apache;

/**
 * 
 * @time 2014年12月11日 上午11:49:30
 * @author jie.liu
 */
public class HttpResponseWrapper {

	public int response;

}
