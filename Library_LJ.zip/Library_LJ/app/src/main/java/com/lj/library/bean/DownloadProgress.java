package com.lj.library.bean;

/**
 * 
 * @time 2014年11月4日 下午1:56:14
 * @author jie.liu
 */
public class DownloadProgress {

	public String threadId;

	public String downloadProgress;

}
