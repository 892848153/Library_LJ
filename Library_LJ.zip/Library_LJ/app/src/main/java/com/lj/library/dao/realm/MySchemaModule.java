package com.lj.library.dao.realm;

import io.realm.annotations.RealmModule;

/**
 * Created by liujie_gyh on 16/6/19.
 */
@RealmModule(allClasses = true)
public class MySchemaModule {
}
