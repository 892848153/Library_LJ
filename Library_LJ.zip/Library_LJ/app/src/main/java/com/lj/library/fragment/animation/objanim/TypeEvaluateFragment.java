package com.lj.library.fragment.animation.objanim;

import android.os.Bundle;

import com.lj.library.R;
import com.lj.library.fragment.BaseFragment;

/**
 * Created by liujie_gyh on 15/10/17.
 */
public class TypeEvaluateFragment extends BaseFragment {

    @Override
    protected int initLayout(Bundle savedInstanceState) {
        return R.layout.type_evaluate_fragment;
    }

    @Override
    protected void initComp(Bundle savedInstanceState) {

    }
}
