package com.lj.library.application;

//import com.tencent.tinker.loader.app.TinkerApplication;
//import com.tencent.tinker.loader.shareutil.ShareConstants;
//
///**
// * Created by liujie_gyh on 2017/4/13.
// */
//public class SampleApplication extends TinkerApplication {
//
//    public SampleApplication() {
//        super(ShareConstants.TINKER_ENABLE_ALL, "com.lj.library.application.SampleApplicationLike",
//                "com.tencent.tinker.loader.TinkerLoader", false);
//    }
//}
