package com.lj.library.activity;

import android.app.Activity;

import com.lj.library.activity.base.BaseViewModel;

/**
 * @author LJ.Liu
 * @date 2018/5/2.
 */
public class MvvmArchitectureViewModel1 extends BaseViewModel {

    public MvvmArchitectureViewModel1(final Activity context) {
        super(context);
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onDestroy() {

    }

    @Override
    public void onRegisterRxBus() {

    }

    @Override
    public void onRemoveRxBus() {

    }
}
