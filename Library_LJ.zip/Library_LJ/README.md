Library_LJ
==========
![Travis CI](https://travis-ci.org/892848153/Library_LJ.svg?branch=master)  

项目中常用的功能   


